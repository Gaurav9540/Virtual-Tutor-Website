﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;
using System.Text;
using System.Web.Services;
using System.Drawing.Drawing2D;

namespace AI_Project.Website
{
    public partial class tutorial : System.Web.UI.Page
    {
        string CS = ConfigurationManager.ConnectionStrings["dbconn"].ToString();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string parameterValue = HttpContext.Current.Request.QueryString["username"];


                // Check if the parameter exists
                if (!string.IsNullOrEmpty(parameterValue))
                {
                    lblShowName.Text = parameterValue.ToUpper();
                    ScriptManager.RegisterStartupScript(this, GetType(), "secondPage2", "<script>document.getElementById('secondPage').style.display = 'none';</script>", false);
                    ScriptManager.RegisterStartupScript(this, GetType(), "mainPage2", "<script>document.getElementById('mainPage').style.display = 'block';</script>", false);
                    ScriptManager.RegisterStartupScript(this, GetType(), "thirdPage", "<script>document.getElementById('thirdPage').style.display = 'none';</script>", false);
                }
                else
                {
                    Response.Redirect("~/loginPage/login.aspx");
                }
            }
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/LoginPage/login.aspx");
        }

        protected void btnCloseFront_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "secondPage1", "<script>document.getElementById('secondPage').style.display = 'none';</script>", false);
            ScriptManager.RegisterStartupScript(this, GetType(), "mainPage1", "<script>document.getElementById('mainPage').style.display = 'block';</script>", false);
            ScriptManager.RegisterStartupScript(this, GetType(), "thirdPage", "<script>document.getElementById('thirdPage').style.display = 'none';</script>", false);


        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            string classData = "Fifth Class";

            ScriptManager.RegisterStartupScript(this, GetType(), "secondPage1", "<script>document.getElementById('secondPage').style.display = 'block';</script>", false);
            ScriptManager.RegisterStartupScript(this, GetType(), "mainPage1", "<script>document.getElementById('mainPage').style.display = 'none';</script>", false);
            ScriptManager.RegisterStartupScript(this, GetType(), "thirdPage", "<script>document.getElementById('thirdPage').style.display = 'none';</script>", false);
            ScriptManager.RegisterStartupScript(this, GetType(), "subjectValue", "<script>document.getElementById('subjectValue').innerHTML = '" + classData + "';</script>", false);

            ScriptManager.RegisterStartupScript(this, GetType(), "fithClass", "<script>document.getElementById('fithClass').style.display = 'block';</script>", false);

        }

        private string getDescriptionData(string getTitleValue, string getSubjectCode, string subjectValue)
        {
            SqlConnection sqlcon = new SqlConnection(CS);

            string getresult = "";

            string param = "sp_subjectdata";
            sqlcon.Open();
            try
            {
                SqlCommand com = new SqlCommand(param, sqlcon);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@Action", "select");
                com.Parameters.AddWithValue("@class", "");
                com.Parameters.AddWithValue("@subject", "");
                com.Parameters.AddWithValue("@subjectcode", getSubjectCode);
                com.Parameters.AddWithValue("@title", getTitleValue);
                com.Parameters.AddWithValue("@decription", "");
                com.Parameters.AddWithValue("@videolink", "");
                com.Parameters.AddWithValue("@createdOn", "");
                com.Parameters.AddWithValue("@lastupdatedon", "");
                SqlDataReader reader = com.ExecuteReader();

                StringBuilder htmlTable = new StringBuilder();
                Literal1.Text = "";
                htmlTable.Append("<table border='1'>");
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        // Read data from each row and add to the HTML table
                        string decription = reader["decription"].ToString();
                        //string column2Data = reader["title"].ToString();
                        htmlTable.Append("<tr>");
                        htmlTable.Append("<td style='padding: 10px;'>" + decription + "</td>");

                        //htmlTable.Append("<td>" + column2Data + "</td>");
                        htmlTable.Append("</tr>");
                    }
                    htmlTable.Append("</table>");
                    Literal1.Text = htmlTable.ToString();


                    getresult = "pass";

                }
                else
                {
                    //reader has no row
                    Literal1.Text = "Records not found, try again after sometime".ToString();
                    getresult = "fail";
                }
                reader.Close(); // Close the SqlDataReader

            }
            catch (Exception ex)
            {
                Literal1.Text = "Records not found, try again after sometime".ToString();
                getresult = "fail";
            }
            return getresult;

        }

        protected void showDescriptionData(object sender, EventArgs e)
        {
            string getTitleValue = txtgetTitleValue.Text;
            string getSubjectCode = txtgetSubjectCode.Text;
            string subjectValue = txtsubjectValue.Text;

            // getTitleValue = "Wonderful Waste!";
            //getSubjectCode = "51";
            //subjectValue = "English";btnselectsubject

            string result = "";
            string getVidoResult = "";
            result = getDescriptionData(getTitleValue, getSubjectCode, subjectValue);
            getVidoResult = getVideoLink(getSubjectCode);
            if (result == "pass" || getVidoResult=="pass")
            {
                getSubject.Text = subjectValue + " Tutorial";
                ScriptManager.RegisterStartupScript(this, GetType(), "subjectTutor", "<script>document.getElementById('subjectTutor').innerHTML = '" + subjectValue + "';</script>", false);
                ScriptManager.RegisterStartupScript(this, GetType(), "thirdPage", "<script>document.getElementById('thirdPage').style.display = 'block';</script>", false);
                ScriptManager.RegisterStartupScript(this, GetType(), "secondPage", "<script>document.getElementById('secondPage').style.display = 'none';</script>", false);
                ScriptManager.RegisterStartupScript(this, GetType(), "mainPage", "<script>document.getElementById('mainPage').style.display = 'none';</script>", false);
                ScriptManager.RegisterStartupScript(this, GetType(), "descriptionarea", "<script>document.getElementById('descriptionarea').style.display = 'block';</script>", false);
                ScriptManager.RegisterStartupScript(this, GetType(), "subjectTitleDescription", "<script>document.getElementById('subjectTitleDescription').innerHTML = '" + getTitleValue + "';</script>", false);

            }
            else
            {

            }

        }

        protected void getValueForNextPage(object sender, EventArgs e)
        {

            string classData = "Fifth Class";
            ScriptManager.RegisterStartupScript(this, GetType(), "thirdPage", "<script>document.getElementById('thirdPage').style.display = 'none';</script>", false);
            ScriptManager.RegisterStartupScript(this, GetType(), "secondPage", "<script>document.getElementById('secondPage').style.display = 'block';</script>", false);
            ScriptManager.RegisterStartupScript(this, GetType(), "mainPage", "<script>document.getElementById('mainPage').style.display = 'none';</script>", false);

            ScriptManager.RegisterStartupScript(this, GetType(), "subjectValue", "<script>document.getElementById('subjectValue').innerHTML = '" + classData + "';</script>", false);

            ScriptManager.RegisterStartupScript(this, GetType(), "fithClass", "<script>document.getElementById('fithClass').style.display = 'block';</script>", false);
           
          



        }
        protected void btngetselectsubject(object sender, EventArgs e)
        {
            string classValue = "fifth";
            string subjectValue = "English";
            string subjectCodeValue = "51";
            string getResult = "";
            string getVidoResult = "";

            getResult = getTitle(classValue, subjectValue, subjectCodeValue);
            
            if (getResult == "pass")
            {
                getSubject.Text = subjectValue + " Tutorial";
                ScriptManager.RegisterStartupScript(this, GetType(), "subjectTutor", "<script>document.getElementById('subjectTutor').innerHTML = '" + subjectValue + "';</script>", false);
                ScriptManager.RegisterStartupScript(this, GetType(), "thirdPage", "<script>document.getElementById('thirdPage').style.display = 'block';</script>", false);
                ScriptManager.RegisterStartupScript(this, GetType(), "secondPage", "<script>document.getElementById('secondPage').style.display = 'none';</script>", false);
                ScriptManager.RegisterStartupScript(this, GetType(), "mainPage", "<script>document.getElementById('mainPage').style.display = 'none';</script>", false);
                Literal1.Text = "";
                videoLiteral.Text = "";
            }
        }

        private string getVideoLink(string subjectCodeValue)
        {
            string getResult = "";


            SqlConnection sqlcon = new SqlConnection(CS);
            StringBuilder htmlTable = new StringBuilder();

            string param = "sp_subjectdata";
            sqlcon.Open();
            try
            {
                SqlCommand com = new SqlCommand(param, sqlcon);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@Action", "getvideo");
                com.Parameters.AddWithValue("@class", "");
                com.Parameters.AddWithValue("@subject", "");
                com.Parameters.AddWithValue("@subjectcode", subjectCodeValue);
                com.Parameters.AddWithValue("@title", "");
                com.Parameters.AddWithValue("@decription", "");
                com.Parameters.AddWithValue("@videolink", "");
                com.Parameters.AddWithValue("@createdOn", "");
                com.Parameters.AddWithValue("@lastupdatedon", "");
                SqlDataReader reader = com.ExecuteReader();
                videoLiteral.Text = "";
                htmlTable.Append("<table border='1'>");

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        // Read data from each row
                        //string title = reader["title"].ToString();
                        string videoLink = reader["videolink"].ToString(); // Assuming "video_link" is the column name in your database

                        // Add the data to the HTML table
                        if (videoLink != " ")
                        {
                            if (IsValidYouTubeLink(videoLink))
                            {
                                // Add the video link to the HTML table
                                htmlTable.Append("<tr>");
                                htmlTable.Append("<td style='padding: 10px;'>");
                                htmlTable.Append("<div class='video-container'>");
                                htmlTable.Append("<iframe width='140' height='100' src='" + videoLink + "' frameborder='0' allowfullscreen></iframe>");
                                htmlTable.Append("</div>");
                                htmlTable.Append("</td>");
                                htmlTable.Append("</tr>");
                            }
                            else
                            {
                                // Invalid YouTube video link
                                // You can handle this case as needed
                            }

                            // htmlTable.Append("<td style='padding: 10px;'><div class='video-box' data-video='" + videoLink + "'><a href='javascript:void(0);' onclick='playVideo(\"" + videoLink + "\");'>Play Video</a></div></td>");
                            //htmlTable.Append("<tr>");
                            //htmlTable.Append("<td style='padding: 10px;'>");
                            //htmlTable.Append("<div class='video-container'>");
                            //htmlTable.Append("<iframe width='140' height='100' src='" + videoLink + "' frameborder='0' allowfullscreen></iframe>");
                            //htmlTable.Append("</div>");
                            //htmlTable.Append("</td>");

                            //htmlTable.Append("</tr>");
                        }
                    }
                    htmlTable.Append("</table>");
                    videoLiteral.Text = htmlTable.ToString();
                    getResult = "pass";
                }
                else
                {
                    // No rows returned from the database
                    getResult = "fail";
                }

                reader.Close(); // Close the SqlDataReader

            }
            catch (Exception ex)
            {
                getResult = "fail" + ex.ToString();
            }


            return getResult;
        }

        private bool IsValidYouTubeLink(string videoLink)
        {
            // Check if the video link is a valid YouTube URL
            return Uri.TryCreate(videoLink, UriKind.Absolute, out Uri uriResult) &&
                   (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps) &&
                   uriResult.Host == "www.youtube.com";
        }

        // Function to convert YouTube URLs to the embed format
        private string ConvertToEmbedLink(string videoLink)
        {
            // Check if the link is already in the embed format
            if (videoLink.StartsWith("https://www.youtube.com/embed/"))
            {
                return videoLink; // Return the link as is
            }

            // Extract the video ID from the URL
            string videoId = videoLink.Substring(videoLink.LastIndexOf("v=") + 2);

            // Construct the embed link
            return "https://www.youtube.com/embed/" + videoId;
        }

        private string getTitle(string classValue, string subjectValue, string subjectCodeValue)
        {
            string getResult = "";


            SqlConnection sqlcon = new SqlConnection(CS);
            StringBuilder htmlTable = new StringBuilder();

            string param = "sp_subjectdata";
            sqlcon.Open();
            try
            {
                SqlCommand com = new SqlCommand(param, sqlcon);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@Action", "display_title");
                com.Parameters.AddWithValue("@class", classValue);
                com.Parameters.AddWithValue("@subject", subjectValue);
                com.Parameters.AddWithValue("@subjectcode", subjectCodeValue);
                com.Parameters.AddWithValue("@title", "");
                com.Parameters.AddWithValue("@decription", "");
                com.Parameters.AddWithValue("@videolink", "");
                com.Parameters.AddWithValue("@createdOn", "");
                com.Parameters.AddWithValue("@lastupdatedon", "");
                SqlDataReader reader = com.ExecuteReader();
                yourLiteralControl.Text = "";
                htmlTable.Append("<table border='1'>");

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        // Read data from each row and add to the HTML table
                        string column1Data = reader["title"].ToString();
                        //string column2Data = reader["title"].ToString();
                        htmlTable.Append("<tr>");
                        //htmlTable.Append("<td style='padding: 10px;'><a href='javascript:void(0);' onclick='getDecription(\"" + column1Data + "\ ,\""+ subjectValue + "\" ,\""+ subjectCodeValue + "\"");'>" + column1Data + "</a></td>");
                        htmlTable.Append("<td style='padding: 10px;'><a href='javascript:void(0);' onclick='getDecription(\"" + column1Data + "\",\"" + subjectValue + "\",\"" + subjectCodeValue + "\");'>" + column1Data + "</a></td>");


                        //htmlTable.Append("<td>" + column2Data + "</td>");
                        htmlTable.Append("</tr>");
                    }
                    htmlTable.Append("</table>");
                    yourLiteralControl.Text = htmlTable.ToString();
                    getResult = "pass";


                }
                else
                {
                    //reader has no row
                    getResult = "fail";
                }


                reader.Close(); // Close the SqlDataReader

            }
            catch (Exception ex)
            {
                getResult = "faile" + ex.ToString();
            }


            return getResult;
        }


        [WebMethod]
        public static List<string> GetDataFromDatabase()
        {
            // Your code to retrieve data from the database
            // For demonstration purposes, let's return some sample data
            List<string> data = new List<string>();
            data.Add("Data 1");
            data.Add("Data 2");
            data.Add("Data 3");
            return data;
        }
    }
}